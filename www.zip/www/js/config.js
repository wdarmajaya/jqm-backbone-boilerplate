var config = {

	//config Variables
	propertyName: "Atlantic Tele-Network, Inc.",
	propertyStreetAddress: "600 Cummings Center, Beverly, MA 01915",
	propertyContactPhoneDisplay: "1.978.619.1300",
	propertyContactPhoneLink: "+19786191300",
	propertyHomePageUrl: "http://atni.com",
	propertyLogoSrc: "img/atn-logo.jpg",

	//Google Analytics
	gaIdWeb: "UA-27585226-20", //Property Name = ATNI Boilerplate
	gaIdApp: "UA-27585226-21" //App Name = ATNI Boilerplate app

}