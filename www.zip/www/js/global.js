//Global Variables
var GA_ID_APP = "UA-99999999-99";